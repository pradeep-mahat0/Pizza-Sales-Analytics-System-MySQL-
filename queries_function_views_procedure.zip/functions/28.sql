-- Returns the category of a given pizza.
DELIMITER //
CREATE FUNCTION get_category_name(pizza_id TEXT)
RETURNS TEXT
DETERMINISTIC
BEGIN
    DECLARE cat TEXT;
    SELECT pt.category INTO cat
    FROM pizzas p
    JOIN pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
    WHERE p.pizza_id = pizza_id;
    RETURN cat;
END;
//
DELIMITER ;
