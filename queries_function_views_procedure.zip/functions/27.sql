-- Returns the total price of all pizzas in a given order.

DELIMITER //
CREATE FUNCTION get_order_total(order_id INT)
RETURNS DOUBLE
DETERMINISTIC
BEGIN
    DECLARE total DOUBLE;
    SELECT SUM(p.price * od.quantity) INTO total
    FROM order_details od
    JOIN pizzas p ON od.pizza_id = p.pizza_id
    WHERE od.order_id = order_id;
    RETURN ROUND(total, 2);
END;
//
DELIMITER ;
