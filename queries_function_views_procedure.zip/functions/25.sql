-- Returns revenue for a single item.

DELIMITER //
CREATE FUNCTION calculate_revenue(price DOUBLE, quantity INT)
RETURNS DOUBLE
DETERMINISTIC
BEGIN
    RETURN ROUND(price * quantity, 2);
END;
//
DELIMITER ;
