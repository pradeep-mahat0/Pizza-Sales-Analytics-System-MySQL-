-- Returns the price of a given pizza.
DELIMITER //
CREATE FUNCTION get_pizza_size_price(pizza_id TEXT)
RETURNS DOUBLE
DETERMINISTIC
BEGIN
    DECLARE pizza_price DOUBLE;
    SELECT price INTO pizza_price FROM pizzas WHERE pizzas.pizza_id = pizza_id;
    RETURN pizza_price;
END;
//
DELIMITER ;
