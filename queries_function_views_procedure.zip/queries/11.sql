SELECT pt.name,
       ROUND(SUM(od.quantity * p.price), 2) AS revenue,
       ROUND(100 * SUM(od.quantity * p.price) / 
             (SELECT SUM(od.quantity * p.price)
              FROM order_details od
              JOIN pizzas p ON od.pizza_id = p.pizza_id), 2) AS percentage
FROM order_details od
JOIN pizzas p ON od.pizza_id = p.pizza_id
JOIN pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
GROUP BY pt.name
ORDER BY percentage DESC;
