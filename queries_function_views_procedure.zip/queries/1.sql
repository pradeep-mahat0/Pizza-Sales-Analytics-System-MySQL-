SELECT COUNT(*) AS total_orders FROM orders;
