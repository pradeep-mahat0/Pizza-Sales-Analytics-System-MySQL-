SELECT o.order_date,
       ROUND(SUM(p.price * od.quantity), 2) AS daily_revenue,
       ROUND(SUM(SUM(p.price * od.quantity)) OVER (ORDER BY o.order_date), 2) AS cumulative_revenue
FROM orders o
JOIN order_details od ON o.order_id = od.order_id
JOIN pizzas p ON od.pizza_id = p.pizza_id
GROUP BY o.order_date;
