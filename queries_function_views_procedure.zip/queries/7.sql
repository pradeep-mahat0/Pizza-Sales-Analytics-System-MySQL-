SELECT HOUR(order_time) AS hour_of_day, COUNT(*) AS num_orders
FROM orders
GROUP BY hour_of_day
ORDER BY num_orders DESC;
