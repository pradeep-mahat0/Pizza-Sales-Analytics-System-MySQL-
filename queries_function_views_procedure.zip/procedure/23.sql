-- Returns total revenue for pizzas in a given category.

DELIMITER //
CREATE PROCEDURE get_pizza_revenue_by_category(IN category_name TEXT)
BEGIN
    SELECT pt.name, ROUND(SUM(p.price * od.quantity), 2) AS revenue
    FROM order_details od
    JOIN pizzas p ON od.pizza_id = p.pizza_id
    JOIN pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
    WHERE pt.category = category_name
    GROUP BY pt.name
    ORDER BY revenue DESC;
END //
DELIMITER ;
