-- Returns number of orders placed in each hour.

DELIMITER //
CREATE PROCEDURE get_order_distribution_by_hour()
BEGIN
    SELECT HOUR(order_time) AS hour_of_day, COUNT(*) AS total_orders
    FROM orders
    GROUP BY hour_of_day
    ORDER BY hour_of_day;
END //
DELIMITER ;
