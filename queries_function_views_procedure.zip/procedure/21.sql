-- Returns top n pizzas based on quantity sold. 
DELIMITER //
CREATE PROCEDURE get_top_n_pizzas_by_quantity(IN n INT)
BEGIN
    SELECT pt.name, SUM(od.quantity) AS total_quantity
    FROM order_details od
    JOIN pizzas p ON od.pizza_id = p.pizza_id
    JOIN pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
    GROUP BY pt.name
    ORDER BY total_quantity DESC
    LIMIT n;
END //
DELIMITER ;
