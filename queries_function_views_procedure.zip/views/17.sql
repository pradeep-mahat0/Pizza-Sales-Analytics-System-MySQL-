-- Displays number of orders grouped by hour of the day.
CREATE VIEW view_hourly_order_distribution AS
SELECT HOUR(order_time) AS hour_of_day, COUNT(*) AS order_count
FROM orders
GROUP BY hour_of_day
ORDER BY hour_of_day;
